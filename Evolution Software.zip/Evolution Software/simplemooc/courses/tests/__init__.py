from .test_views import ContactCourseTestCase
from .test_models import CourseManagerTestCase
